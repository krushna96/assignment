import { Component, OnInit } from '@angular/core';
import { DataAccessService } from '../data-access.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  results:any;
  constructor(private service:DataAccessService) { }

  ngOnInit(): void {
    this.service.getData().subscribe(response=>{
      this.results=response;

      console.log(this.results)
    });
    
  }

}
